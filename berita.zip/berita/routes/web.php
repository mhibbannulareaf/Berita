<?php



Route::get('/home', function () {
    return view('home');
});

Route::resource('/category','CategoryController');
route::resource('/tag', 'TagsController');
route::resource('/post', 'PostController');