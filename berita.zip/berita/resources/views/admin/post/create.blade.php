@extends('template_backend.home')
@section('sub-judul', 'Post')
@section('content')


@if (count($errors)>0)
    @foreach ($errors->all() as $error)
    <div class="alert alert-danger" role="alert">
        {{$error}}
      </div>
    @endforeach
@endif

@if (Session::has('success'))
<div class="alert alert-success" role="alert">
    {{Session('success')}}
  </div>
@endif

<form action="{{route('post.store')}}" method="POST">
    @csrf
    <div class="from-group">
        <label>Judul</label>
        <input type="text" class="form-control" name="judul"> 
    </div>
    <div class="from-group">
        <label>Kategory</label>
        <select class="form-control" name="category_id">
            <option value=""holder>Pilih Kategory</option>
            @foreach ($category as $result)
                <option value="{{$result->id}}">{{$result->name}}</option>
            @endforeach
        </select>
        <div class="from-group">
            <label>Konten</label>
            <textarea name="content" class="form-control"><textarea>
        </div>
        <div class="form-group">
            <label for="">Thumbnail</label>
            <input type="file" name="gambar" class="form-control">
        </div>
    </div>
</form>

@endsection